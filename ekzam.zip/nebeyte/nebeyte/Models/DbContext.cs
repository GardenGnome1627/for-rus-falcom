﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nebeyte.Models
{
    public class AppDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; } // у меня на пк поехал клиент sql-сервер'а извините не могу подключить бд
    }
}
